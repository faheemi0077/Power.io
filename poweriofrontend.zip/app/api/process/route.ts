import { NextRequest, NextResponse } from "next/server";

const BACKEND_URL = "https://poweriobackendv1cl.onrender.com";

export async function POST(request: NextRequest) {
  try {
    const apiKey = request.headers.get("X-API-KEY");
    if (!apiKey) {
      return NextResponse.json({ error: "API key is required" }, { status: 401 });
    }

    // Forward the entire multipart form body to the backend
    const formData = await request.formData();

    // Reconstruct FormData for the backend
    const backendFormData = new FormData();

    const pptxFile = formData.get("pptxFile");
    if (pptxFile) {
      backendFormData.append("pptxFile", pptxFile);
    }

    const dataFiles = formData.getAll("dataFiles");
    for (const file of dataFiles) {
      backendFormData.append("dataFiles", file);
    }

    const instructions = formData.get("instructions");
    if (instructions) {
      backendFormData.append("instructions", instructions as string);
    }

    const backendResponse = await fetch(`${BACKEND_URL}/process`, {
      method: "POST",
      headers: {
        "X-API-KEY": apiKey,
      },
      body: backendFormData,
    });

    if (!backendResponse.ok) {
      const errorText = await backendResponse.text();
      let errorJson;
      try {
        errorJson = JSON.parse(errorText);
      } catch {
        errorJson = { error: errorText || `Backend returned ${backendResponse.status}` };
      }
      return NextResponse.json(errorJson, { status: backendResponse.status });
    }

    // Stream the PPTX file back to the client
    const blob = await backendResponse.blob();
    return new NextResponse(blob, {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "Content-Disposition": 'attachment; filename="output.pptx"',
      },
    });
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Internal server error";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}


